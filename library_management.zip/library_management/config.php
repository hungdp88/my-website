<?php
return [
    'host'=>'localhost',
    'dbname'=>'library_oop_db',
    'username'=>'root',
    'password'=>''
];
