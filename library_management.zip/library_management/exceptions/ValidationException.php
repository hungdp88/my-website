<?php

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    try {
        if (empty($_POST["title"]) || empty($_POST["author"]) || intval($_POST["published_year"]) <= 0 || intval($_POST["copies"]) < 1) {
            throw new ValidationException("Dữ liệu không hợp lệ!");
        }
        $book->insertBook($_POST["title"], $_POST["author"], intval($_POST["published_year"]), intval($_POST["copies"]));
        echo "Thêm sách thành công!";
    } catch (ValidationException $e) {
        echo "Lỗi: " . $e->getMessage();
    }
}